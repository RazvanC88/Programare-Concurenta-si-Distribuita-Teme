﻿using System;
using Tron.Net.Client.Grpc.Configuration;

namespace Tron.Examples
{
    public class SimpleChannelConfiguration : IChannelConfiguration
    {
        private const int DefaultTimeOutMs = 30000;

        public SimpleChannelConfiguration()
        {
            Host = "api.trongrid.io";
            Port = 8090;
        }

        public int Port { get; }
        public string Host { get; }
        public int? MaxConcurrentStreams { get; }
        public TimeSpan? TimeOutMs { get; }
    }
}
