﻿using System;
using System.Text;
using Google.Protobuf;
using Tron.Net.Client.Grpc;
using Tron.Net.Client.Grpc.Configuration;
using Tron.Net.Protocol;
using Wallet = Tron.Net.Client.Wallet;

namespace Tron.Examples
{
    class Program
    {
        static void Main(string[] args)
        {
            var configuration = new SimpleChannelConfiguration();
            var grpcChannelFactory = new GrpcGrpcChannelFactory(configuration);
            var walletClientFactory = new WalletClientFactory(grpcChannelFactory);
            var wallet = new Wallet(walletClientFactory, new AllClientsDefaultCallConfiguration());

            var x = wallet.GetNowBlockAsync().GetAwaiter().GetResult();

            var result = wallet.CreateTransactionAsync(new TransferContract
            {
                Amount = (long) 0.0001,
                OwnerAddress = ByteString.CopyFromUtf8("abcdefghijkl"),
                ToAddress = ByteString.CopyFromUtf8("abcdefghijkl")
            }).Result;

            Console.WriteLine(result.RawData);
        }
    }
}