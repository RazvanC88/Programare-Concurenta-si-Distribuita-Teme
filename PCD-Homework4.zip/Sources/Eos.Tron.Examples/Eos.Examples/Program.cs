﻿using System;
using System.Collections.Generic;
using EosSharp.Core;
using EosSharp.Core.Api.v1;
using EosSharp.Core.Providers;
using Action = EosSharp.Core.Api.v1.Action;

namespace Eos.Examples
{
    class Program
    {
        static void Main(string[] args)
        {
            var eos = new EosSharp.Eos(new EosConfigurator
            {
                HttpEndpoint = "http://jungle2.cryptolions.io:80", //Testnet
                ChainId = "e70aaab8997e1dfce58fbfac80cbbb8fecec7b99cf982a9444273cbc64c41473",
                ExpireSeconds = 60,
                SignProvider = new DefaultSignProvider("5KDhYhnALyZKePpMKqgWwm6UYbs2nvk5Sn7mwa9Yz35K3QXmdTe"),
            });

            var infoResponse = eos.GetInfo().Result;

            var result = eos.GetAccount("abcdefghijkl").Result;

            var result2 = eos.CreateTransaction(new Transaction()
            {
                actions = new List<Action>()
                {
                    new Action()
                    {
                        account = "abcdefghijkl",
                        authorization = new List<PermissionLevel>()
                        {
                            new PermissionLevel() {actor = "tester112345", permission = "active" }
                        },
                        name = "transfer",
                        data = new
                        {
                            from = "tester112345",
                            to = "tester212345",
                            quantity = "0.0001 EOS",
                            memo = "hello crypto world!"
                        }
                    }
                }
            });

            var transaction = eos.GetTransaction("32").Result;
            Console.WriteLine(transaction.trx.receipt.status);
        }
    }
}
